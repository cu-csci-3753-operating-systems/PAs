#include "array.h"

// your thread-safe array implementation here
